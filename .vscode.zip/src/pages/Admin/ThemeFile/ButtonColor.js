//   export const ButtonColor='#45C165'
import React from 'react'

export default function ButtonColor() {
    const ButtonColor ='#45C165'
  return (
    <div>{ButtonColor}</div>
  )
}

