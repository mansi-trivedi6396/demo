import React from 'react'
import Settings from '../../Component/Settings/index'

function SettingPage() {
    return (
        <Settings />
    )
}

export default SettingPage